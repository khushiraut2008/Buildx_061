# Style review — revision plan (one pass, holistic)

1. Push editorial grid through Skills & Education: recast as index/ledger
   rows with dotted leaders, mono labels, serif emphasis — not cards/table.
2. Unify imagery: captioned "fig." paper figures everywhere; remove the
   generic photographic portrait (two identities) — keep only the
   illustrated figure as fig. 01; About uses the illustration in a figure
   frame with annotations OR drop photo and use a large annotated serif
   blockquote/initial. Choose: replace photo with editorial figure using
   the same illustration motif is repetitive → use text-only annotated
   figure: a framed "margin notes" block (index card style) with fig. 02
   caption.
3. Dark contact = "ink back cover": keep dark but add hairline rules,
   dotted-leader rows for links, mono metadata, print grammar.
4. Brand seal: make header logo bigger + stamp-like; fig captions with
   terracotta annotation marks.
