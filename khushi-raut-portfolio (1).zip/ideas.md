# Khushi Raut — Portfolio Design Brainstorm

## Three Stylistic Approaches

1. **Theme Name: "Editorial Paper"**
   - Very Brief Intro: A warm, print-inspired portfolio that reads like a beautifully typeset journal page — cream paper tones, serif display type, ink accents, and ruled-line motifs. Feels personal, thoughtful, and quietly confident.
   - Probability: 0.06

2. **Theme Name: "Terminal Blossom"**
   - Very Brief Intro: A dark developer-console aesthetic softened with warm gradient accents and handwritten-feel highlights — code-as-craft energy for an engineering student.
   - Probability: 0.03

3. **Theme Name: "Data Canvas"**
   - Very Brief Intro: A cool, analytical look with graph-paper grids, scatter-dot textures, and teal/coral data-viz color pairings — presenting Khushi as an aspiring data/AI analyst.
   - Probability: 0.04

## CHOSEN: Editorial Paper

- **Design Movement**: Contemporary editorial / Swiss print design (think academic zines, Kinfolk-style layouts) — typography-forward, warm paper palette, asymmetrical column grids.
- **Core Principles**:
  1. Typography is the interface — big serif display headings carry the visual weight.
  2. Asymmetric layouts: off-center hero, staggered two-column sections, sticky side labels.
  3. Paper texture & ruled lines: subtle grain, hairline rules, index-style numbered sections (01 / 02 / 03).
  4. Restraint: one accent color used sparingly; nothing glows, nothing floats without purpose.
- **Color Philosophy**: Warm cream paper background (#FAF6EF family) with near-black ink (#1A1713) text; a single burnt-orange/terracotta accent (oklch ~0.62 0.15 40) for links, underlines, and highlights — evokes ink-stamped seals and margin notes. Emotional intent: warmth, sincerity, hand-crafted.
- **Layout Paradigm**: Magazine spread — hero is a left-heavy asymmetric composition with oversized serif name and a right-aligned portrait card; sections numbered like journal chapters; a vertical sticky nav rail with section labels on desktop.
- **Signature Elements**:
  1. Numbered section labels ("01 — About") in small-caps mono with a hairline rule.
  2. Terracotta underline/bracket marks on names and links.
  3. Dotted-leader lines (like a table of contents) connecting labels to content.
- **Interaction Philosophy**: Quiet and tactile — links get terracotta underlines that draw in on hover; cards lift 2px with soft paper shadow; scroll reveals fade-up gently (≤300ms, ease-out).
- **Animation**: Entrance = fade + translateY(12px), 350ms cubic-bezier(0.23,1,0.32,1), staggered 60ms; hover underline slides in 180ms; buttons scale(0.97) on active. Respect prefers-reduced-motion.
- **Typography System**: "Fraunces" (serif display, optical sizes, soft warm character) for headings + name; "Inter"-free body → use "Source Sans 3" for body; "IBM Plex Mono" for labels, numbers, and links. Hierarchy: Fraunces 600/700 for H1–H3, body 16–17px/1.7, mono 12–13px uppercase tracking-wide for metadata.
- **Brand Essence**: A student engineer's personal index — data & AI curious, sincerely written, for recruiters and peers. Personality: warm, precise, curious.
- **Brand Voice**: First-person, understated, concrete. Example headline: "Hi, I'm Khushi — I write code and look for the story in data." Example CTA: "Download my resume →". Ban generic filler like "Welcome to my portfolio" / "Get started today".
- **Wordmark & Logo**: Lowercase monogram "kr." in Fraunces italic with a terracotta period as a stamped seal motif; used in header and favicon.
- **Signature Brand Color**: Terracotta (burnt orange) — unmistakably warm ink-on-paper.

## Style Decisions
- Imagery follows one editorial rule: every image is a captioned paper figure with a mono "fig." label and ink/terracotta annotation; no uncaptioned stock-like visuals.
- Skills and education never use generic dashboard cards; they read as index/ledger pages built from rules, numbers, dotted leaders, and serif/mono hierarchy.
- Dark sections are only an "ink back cover": same print grammar (hairline rules, mono labels, dotted leaders, restrained terracotta), no generic SaaS CTA styling.
