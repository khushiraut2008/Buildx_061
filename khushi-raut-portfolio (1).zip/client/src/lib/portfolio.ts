/**
 * DESIGN: "Editorial Paper" — central data file for Khushi Raut's portfolio.
 * All contact links, resume asset, skills, and education live here.
 */
import { Mail, Github, Linkedin, FileText } from "lucide-react";

export const RESUME_URL = "/assets/Khushi_Raut_Resume.pdf";

export const LINKS = [
  {
    label: "Email",
    href: "mailto:khushiraut930@gmail.com",
    value: "khushiraut930@gmail.com",
    icon: Mail,
  },
  {
    label: "GitHub",
    href: "https://github.com/khushiraut2008",
    value: "khushiraut2008",
    icon: Github,
  },
  {
    label: "LinkedIn",
    href: "https://www.linkedin.com/in/khushi-raut/",
    value: "Khushi Raut",
    icon: Linkedin,
  },
];

export const IMAGES = {
  hero: "/assets/kr-hero-illustration.webp",
  portrait: "/assets/kr-portrait-frame.webp",
  texture: "/assets/kr-paper-texture.webp",
  logo: "/assets/kr-logo-mark.png",
};

export const SECTION_ICONS = {
  resume: FileText,
};

export interface SkillGroup {
  category: string;
  items: string[];
}

export const SKILL_GROUPS: SkillGroup[] = [
  { category: "Languages", items: ["C", "C++", "Python (learning)"] },
  { category: "Data", items: ["Data Analysis", "Spreadsheet Analytics", "Data Visualization"] },
  { category: "Interests", items: ["Artificial Intelligence", "Software Development", "Machine Learning"] },
];

export interface EducationEntry {
  qualification: string;
  institution: string;
  detail: string;
}

export const EDUCATION: EducationEntry[] = [
  {
    qualification: "B.Tech — Computer Science",
    institution: "Govindrao Wanjari College of Engineering",
    detail: "Pursuing",
  },
  {
    qualification: "HSC",
    institution: "Abhinanadan Junior College",
    detail: "57%",
  },
  {
    qualification: "SSC",
    institution: "Adhinanadan High School",
    detail: "68%",
  },
];

export const CAREER_INTERESTS = [
  "Data Analysis",
  "Artificial Intelligence",
  "Software Development",
];
