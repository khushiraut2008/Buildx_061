/**
 * DESIGN: "Editorial Paper" — magazine-spread portfolio for Khushi Raut.
 * Cream paper bg, Fraunces serif display, IBM Plex Mono labels, terracotta
 * accent, numbered journal sections, dotted leaders, asymmetric layout.
 *
 * Style Decisions (from review):
 * - Every image is a captioned paper figure with mono "fig." labels.
 * - Skills & education read as index/ledger pages (rules, numbers, dotted
 *   leaders), never dashboard cards.
 * - The dark contact section is an "ink back cover" with print grammar:
 *   hairline rules, mono metadata, dotted-leader rows, restrained terracotta.
 */
import { ArrowUpRight, ArrowRight } from "lucide-react";
import {
  RESUME_URL,
  LINKS,
  IMAGES,
  SKILL_GROUPS,
  EDUCATION,
  CAREER_INTERESTS,
} from "@/lib/portfolio";
import { useReveal } from "@/hooks/useReveal";

function SectionLabel({ index, title }: { index: string; title: string }) {
  return (
    <div className="hairline flex items-baseline gap-4 pb-3 mb-10">
      <span className="mono-label text-terracotta">{index}</span>
      <span className="mono-label text-muted-foreground">{title}</span>
    </div>
  );
}

export default function Home() {
  useReveal();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* ---------- Header ---------- */}
      <header className="sticky top-0 z-40 bg-background/90 backdrop-blur-md hairline">
        <div className="container flex items-center justify-between py-4">
          <a href="#top" className="flex items-center gap-3">
            <img
              src={IMAGES.logo}
              alt="kr. seal"
              className="h-12 w-12 object-contain"
            />
            <span className="flex flex-col leading-none">
              <span className="font-serif text-2xl font-semibold tracking-tight">
                Khushi Raut<span className="text-terracotta">.</span>
              </span>
              <span className="mono-label text-muted-foreground mt-1.5">
                personal index · est. 2026
              </span>
            </span>
          </a>
          <nav className="hidden md:flex items-center gap-8">
            {["About", "Skills", "Education", "Contact"].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="mono-label text-foreground/70 hover:text-terracotta transition-colors duration-200"
              >
                {item}
              </a>
            ))}
            <a
              href={RESUME_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="mono-label bg-foreground text-background px-4 py-2 hover:bg-terracotta hover:text-primary-foreground transition-colors duration-200 active:scale-[0.97]"
            >
              Resume
            </a>
          </nav>
        </div>
      </header>

      {/* ---------- Hero ---------- */}
      <section id="top" className="container pt-16 md:pt-24 pb-16 md:pb-20">
        <div className="grid md:grid-cols-12 gap-10 items-center">
          <div className="md:col-span-7">
            <p className="mono-label text-terracotta mb-5 reveal">
              B.Tech Computer Science · Data &amp; AI
            </p>
            <h1 className="font-serif text-5xl md:text-7xl font-semibold leading-[1.05] tracking-tight mb-6 reveal" style={{ "--reveal-delay": "60ms" } as React.CSSProperties}>
              Hi, I'm{" "}
              <span className="ink-underline italic font-medium">Khushi</span>
              — I write code and look for the story in data.
            </h1>
            <p className="text-lg text-muted-foreground max-w-xl mb-9 reveal" style={{ "--reveal-delay": "120ms" } as React.CSSProperties}>
              A computer science student building a foundation in C/C++ and
              data analysis, curious about artificial intelligence and how
              software turns raw numbers into decisions.
            </p>
            <div className="flex flex-wrap items-center gap-4 reveal" style={{ "--reveal-delay": "180ms" } as React.CSSProperties}>
              <a
                href={RESUME_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="mono-label inline-flex items-center gap-2 bg-foreground text-background px-6 py-3.5 hover:bg-terracotta hover:text-primary-foreground transition-colors duration-200 active:scale-[0.97]"
              >
                Download Resume <ArrowRight className="h-4 w-4" />
              </a>
              {LINKS.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mono-label inline-flex items-center gap-2 border border-foreground/25 px-4 py-3 hover:border-terracotta hover:text-terracotta transition-colors duration-200 active:scale-[0.97]"
                >
                  <link.icon className="h-4 w-4" />
                  {link.label}
                </a>
              ))}
            </div>
          </div>
          <div className="md:col-span-5 reveal" style={{ "--reveal-delay": "140ms" } as React.CSSProperties}>
            <figure className="relative paper-shadow">
              <img
                src={IMAGES.hero}
                alt="Illustration of a student working on code and data analysis"
                className="w-full aspect-[4/3] object-cover"
              />
              <figcaption className="mono-label absolute -bottom-4 right-0 bg-background border border-border px-3 py-1.5 text-muted-foreground">
                fig. 01 — code &amp; charts
              </figcaption>
            </figure>
          </div>
        </div>
      </section>

      {/* ---------- About ---------- */}
      <section id="about" className="container py-16 md:py-24">
        <SectionLabel index="01" title="About" />
        <div className="grid md:grid-cols-12 gap-10">
          <div className="md:col-span-4 reveal">
            {/* fig. 02 — a captioned "margin notes" index card,
                consistent with the paper-figure rule (no stock photo) */}
            <figure className="paper-shadow border border-border bg-card p-8 relative">
              <span className="mono-label text-terracotta block mb-4">
                fig. 02 — field notes
              </span>
              <ul className="space-y-4 font-serif text-lg italic">
                <li>— debugging by reading, not guessing</li>
                <li>— data first, conclusions second</li>
                <li>— small tools, clearly explained</li>
                <li>— one honest commit at a time</li>
              </ul>
              <span className="mono-label text-muted-foreground block mt-6 pt-4 hairline">
                khushi raut · working copy
              </span>
            </figure>
          </div>
          <div className="md:col-span-8">
            <p className="text-lg md:text-xl leading-relaxed mb-6 reveal">
              I'm a <span className="ink-underline font-semibold">B.Tech
              Computer Science</span> student at Govindrao Wanjari College of
              Engineering, learning to think like an engineer — starting with
              the discipline of C and C++, and the patterns hidden inside data.
            </p>
            <p className="text-lg md:text-xl leading-relaxed mb-10 reveal">
              My interests sit where <span className="font-semibold">data
              analysis</span> meets{" "}
              <span className="font-semibold">artificial intelligence</span>:
              asking good questions, cleaning messy information, and building
              small software tools that make answers visible. Every project I
              take on is a step toward a career in data and AI technologies.
            </p>
            <div className="hairline reveal">
              {CAREER_INTERESTS.map((interest, i) => (
                <div key={interest} className="flex items-center gap-4 py-3">
                  <span className="mono-label text-terracotta w-10">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="font-serif text-xl">{interest}</span>
                  <span className="dot-leader" />
                  <ArrowUpRight className="h-4 w-4 text-muted-foreground shrink-0" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ---------- Skills — index/ledger page ---------- */}
      <section id="skills" className="bg-[var(--paper-deep)] py-16 md:py-24">
        <div className="container">
          <SectionLabel index="02" title="Skills" />
          <div className="max-w-3xl hairline">
            {SKILL_GROUPS.map((group, gi) =>
              group.items.map((item, ii) => (
                <div
                  key={`${group.category}-${item}`}
                  className="flex items-baseline gap-4 py-4 reveal"
                  style={{ "--reveal-delay": `${(gi * 3 + ii) * 50}ms` } as React.CSSProperties}
                >
                  <span className="mono-label text-terracotta w-10 shrink-0">
                    {String(gi * 10 + ii + 1).padStart(2, "0")}
                  </span>
                  <span className="font-serif text-xl shrink-0">
                    {item}
                    {ii === 0 && (
                      <span className="mono-label ml-3 text-muted-foreground font-normal">
                        {group.category}
                      </span>
                    )}
                  </span>
                  <span className="dot-leader" />
                </div>
              )),
            )}
          </div>
          <p className="mono-label text-muted-foreground mt-8">
            fig. 03 — an evolving index; new entries added as I learn.
          </p>
        </div>
      </section>

      {/* ---------- Education ---------- */}
      <section id="education" className="container py-16 md:py-24">
        <SectionLabel index="03" title="Education" />
        <div className="max-w-3xl hairline">
          {EDUCATION.map((entry) => (
            <div key={entry.qualification} className="grid grid-cols-12 items-baseline gap-2 py-5 reveal">
              <span className="mono-label text-terracotta col-span-2">
                {EDUCATION.indexOf(entry) === 0 ? "—" : "—"}
              </span>
              <span className="col-span-6 font-serif text-xl">{entry.qualification}</span>
              <span className="dot-leader col-span-2" />
              <span className="mono-label text-muted-foreground col-span-2 text-right">
                {entry.detail}
              </span>
            </div>
          ))}
        </div>
        <p className="text-muted-foreground mt-8 max-w-2xl reveal">
          <span className="font-serif italic">
            Govindrao Wanjari College of Engineering
          </span>{" "}
          is where the degree is in progress — the learning, I hope, never is.
        </p>
      </section>

      {/* ---------- Contact — ink back cover ---------- */}
      <section id="contact" className="bg-foreground text-background py-16 md:py-24 border-t-4 border-terracotta">
        <div className="container">
          <p className="mono-label text-[oklch(0.75_0.12_45)] mb-8 hairline pb-3 reveal">
            04 — Contact · back cover
          </p>
          <div className="grid md:grid-cols-12 gap-10 items-start">
            <div className="md:col-span-7">
              <h2 className="font-serif text-4xl md:text-5xl font-semibold leading-tight mb-6 reveal">
                Let's work on something{" "}
                <span className="italic text-[oklch(0.82_0.1_45)]">together</span>.
              </h2>
              <p className="text-background/70 text-lg max-w-md mb-9 reveal">
                Whether it's a project, an internship, or just a good
                conversation about data and code — my inbox is open.
              </p>
              <a
                href={RESUME_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="mono-label inline-flex items-center gap-2 bg-[oklch(0.75_0.12_45)] text-foreground px-6 py-3.5 hover:bg-background transition-colors duration-200 active:scale-[0.97] reveal"
              >
                Download Resume <ArrowRight className="h-4 w-4" />
              </a>
            </div>
            <div className="md:col-span-5 md:justify-self-end w-full reveal">
              <div className="border border-background/30 bg-background/[0.03]">
                {LINKS.map((link, i) => (
                  <a
                    key={link.label}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex items-center gap-4 px-6 py-5 hover:bg-background/10 transition-colors duration-200 ${i !== LINKS.length - 1 ? "border-b border-background/25" : ""}`}
                  >
                    <span className="mono-label text-[oklch(0.75_0.12_45)] w-6">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="mono-label text-background/60 w-20 shrink-0">
                      {link.label}
                    </span>
                    <span className="text-lg shrink-0">{link.value}</span>
                    <span className="dot-leader" />
                    <ArrowUpRight className="h-4 w-4 text-background/50 shrink-0" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ---------- Footer ---------- */}
      <footer className="bg-foreground text-background border-t border-background/15">
        <div className="container py-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img src={IMAGES.logo} alt="kr. seal" className="h-8 w-8 object-contain brightness-0 invert" />
            <span className="font-serif text-lg">Khushi Raut<span className="text-[oklch(0.75_0.12_45)]">.</span></span>
          </div>
          <p className="mono-label text-background/50">
            © {new Date().getFullYear()} · Written with care, styled on paper.
          </p>
        </div>
      </footer>
    </div>
  );
}
